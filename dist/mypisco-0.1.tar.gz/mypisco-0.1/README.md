# mypisco

Program for calculating recursion functionality and sorting items in an array

## Install through github:

`pip install git https://github.com/Thembisile/mypisco.git`

## Update through github:

`pip install --upgrade https://github.com/Thembisile/mypisco`